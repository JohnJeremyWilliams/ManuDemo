print("Hello ITL!")

arr = [20, 17, 45, 2, 34, 14, 12, 15, 27, 11]

def radix(arr):
    #sort the above array using radix sort
